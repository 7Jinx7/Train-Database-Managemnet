Rutgers CS 336: Principles of Information and Database Management
# Train Database Project
Authors: Sanjana Suresh, Shreeyut Neupane, Ron Cohen 

Description:
The purpose of this project was to create a online railway booking system application. This project utilized HTML for user interface, MySQL for the database server, and Java. The web server was through Tomcat.

